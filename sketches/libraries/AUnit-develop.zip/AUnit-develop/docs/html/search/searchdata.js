var indexSectionsWithContent =
{
  0: "acdefgiklmoprstv",
  1: "afmptv",
  2: "acfgmt",
  3: "acdefgilmoprst",
  4: "k",
  5: "t",
  6: "acefpst",
  7: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros",
  7: "Pages"
};

