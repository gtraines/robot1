var searchData=
[
  ['enableverbosity',['enableVerbosity',['../classaunit_1_1Test.html#a3490d139e963b7308e8a201d430bdb8d',1,'aunit::Test']]],
  ['exclude',['exclude',['../classaunit_1_1TestRunner.html#ad55fbb77f52eb2c1a2d45536e8c4afba',1,'aunit::TestRunner::exclude(const char *pattern)'],['../classaunit_1_1TestRunner.html#aacd40834554b476893701d7492d2d550',1,'aunit::TestRunner::exclude(const char *testClass, const char *pattern)']]],
  ['expire',['expire',['../classaunit_1_1Test.html#aab89c47bfa768b0dbf9eb18a777ac4bc',1,'aunit::Test']]]
];
